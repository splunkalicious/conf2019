 require([
     'jquery',
     'splunkjs/mvc',
     'splunkjs/mvc/simplexml/ready!'], function($, mvc,) {
     var submittedTokens = mvc.Components.get('submitted');
     // Listen for a change to the token tokHTML value
     submittedTokens.on("change:search1", function(model, search1, options) {
         var tokHTMLJS=submittedTokens.get("search1");
         if (tokHTMLJS!==undefined)
         {
             tokHTMLJS= "<h1>" + tokHTMLJS.replace(/\|\s/gi,"<br/>| ") + "</h1>" ;
             $("#search1htmlPanel").html(tokHTMLJS);
             tokHTMLJS = highlight(tokHTMLJS);
             $("#search1htmlPanel").html(tokHTMLJS);
         }
     });
     
          submittedTokens.on("change:search2", function(model, search2, options) {
         var tokHTMLJS=submittedTokens.get("search2");
         if (tokHTMLJS!==undefined)
         {
             tokHTMLJS= "<h1>" + tokHTMLJS.replace(/\|\s/gi,"<br/>| ") + "</h1>" ;
             $("#search2htmlPanel").html(tokHTMLJS);
             tokHTMLJS = highlight(tokHTMLJS);
             $("#search2htmlPanel").html(tokHTMLJS);
         }
     });
     
          submittedTokens.on("change:search3", function(model, search3, options) {
         var tokHTMLJS=submittedTokens.get("search3");
         if (tokHTMLJS!==undefined)
         {
             tokHTMLJS= "<h1>" + tokHTMLJS.replace(/\|\s/gi,"<br/>| ") + "</h1>" ;
             $("#search3htmlPanel").html(tokHTMLJS);
             tokHTMLJS = highlight(tokHTMLJS);
             $("#search3htmlPanel").html(tokHTMLJS);
         }
     });
 });

function highlight(tokHTMLJS) {
         if (tokHTMLJS!==undefined)
         {
             
             tokHTMLJS= tokHTMLJS.replace(/\seval\s|\seventstats\s|\sstreamstats\s|\sfields\s|\shead\s|\sstreamstats\s|\srex\s|\stable\s|\sfilldown\s|\swhere\s|\sappendcols\s|\sstats\s|\[search\s/gi, function (x){
                 x= " <span style=\"color:blue\" >" + x + "</span> " ;
                 return x ;
             } ) ;
             tokHTMLJS= tokHTMLJS.replace(/\saddinfo\s|\sgentimes\s|\sappend\s|\stimechart\s|\stranspose|\sreverse\s|\srename\s|\stop\s|\sjoin\s|\stransaction\s|\ssort\s/gi, function (x){
                 x= " <span style=\"color:blue\" >" + x + "</span> " ;
                 return x ;
             } );
             tokHTMLJS= tokHTMLJS.replace(/\sas\s|\sand\s|\sor\s|\snot\s|\sby\s/gi, function (x){
                 x= " <span style=\"color:orange\" >" + x + "</span> " ;
                 return x ;
             } ) ;
             tokHTMLJS= tokHTMLJS.replace(/\scount\s/gi, function (x){  //non-brackeded commands
                 x= " <span style=\"color:fuchsia\" >" + x + "</span> " ;
                 return x ;
             } ) ;
             tokHTMLJS= tokHTMLJS.replace(/last\(|sum\(|if\(|substr\(|len\(|values\(|isnull\(|isnotnull\(/gi, function (x){  //bracketed commands
                 x= " <span style=\"color:fuchsia\" >" + x.replace(/\(/gi,"") + "</span>(" ;
                 return x ;
             }
                    ) ;
             tokHTMLJS= tokHTMLJS.replace(/field=|mode=|window=|current=/gi, function (x){
                 x= " <span style=\"color:green\" >" + x.replace(/=/gi,"") + "</span>=" ;
                 return x ;
             } ) ;
             tokHTMLJS=  tokHTMLJS.replace(/\|\s/gi,"| ") ;
             return tokHTMLJS;
         }
  return null;
}